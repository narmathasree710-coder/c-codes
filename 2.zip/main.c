/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
	float a,b,c,d,e,bill,s,t,gst;
	printf("Amount of 1st item:");
	scanf("%f",&a);
	printf("Amount of 2nd item:");
	scanf("%f",&b);
	printf("Amount of 3rd item:");
	scanf("%f",&c);
	printf("Amount of 4th item:");
	scanf("%f",&d);
	printf("Amount of 5th item:");
	scanf("%f",&e);

	bill=a+b+c+d+e;
	gst=bill*0.05;

	if(bill<500)
	{
		printf("The total bill amount is:%.2f",(bill+gst));
	}

	else if(bill>500)
	{
		s=bill*0.05;
		printf("The total bill amount is:%.2f",(s+gst));
	}

	else if(bill>1000)
	{
		s=bill*0.1;
		printf("The total bill amount is:%.2f",(s+gst));
	}
	else
	{
	    
	}

return 0;
}